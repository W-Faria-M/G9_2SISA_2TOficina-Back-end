-- Inserts iniciais
INSERT INTO tarefa (titulo, descricao, concluida) VALUES
                                                      ('Estudar Kotlin', 'Ler documentação oficial', 0),
                                                      ('Implementar API', 'Criar endpoints REST', 0),
                                                      ('Testar aplicação', 'Usar Insomnia para testar', 0);